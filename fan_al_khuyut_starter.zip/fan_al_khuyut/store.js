(() => {
  const cfg = window.FAN_CONFIG || {};
  const configured = cfg.SUPABASE_URL && cfg.SUPABASE_ANON_KEY &&
    !cfg.SUPABASE_URL.includes("PASTE_") && !cfg.SUPABASE_ANON_KEY.includes("PASTE_");
  const sb = configured && window.supabase ? window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY) : null;
  const grid = document.getElementById("productGrid");
  const empty = document.getElementById("emptyState");
  let products = [];
  let currentFilter = "all";
  document.getElementById("year").textContent = new Date().getFullYear();

  function waLink(text) {
    const number = (cfg.WHATSAPP_NUMBER || "").replace(/\D/g, "");
    return number && !number.includes("XXXXXXXX") ? `https://wa.me/${number}?text=${encodeURIComponent(text)}` : "#contact";
  }
  const headerWa = document.getElementById("headerWhatsApp");
  const contactWa = document.getElementById("contactWhatsApp");
  headerWa.href = waLink("السلام عليكم، بغيت نستفسر على منتجات فن الخيوط.");
  contactWa.href = waLink("السلام عليكم، بغيت نستفسر على منتجات فن الخيوط.");

  function card(p) {
    const typeLabel = p.product_type === "digital" ? "تصميم رقمي" : "منتج مصنوع حسب الطلب";
    const image = p.image_url ? `<img src="${escapeHtml(p.image_url)}" alt="${escapeHtml(p.name)}" loading="lazy">` : `<span class="product-placeholder">🧶</span>`;
    const price = Number(p.price || 0).toLocaleString("ar-MA");
    const msg = `السلام عليكم، مهتم بمنتج "${p.name}" من فن الخيوط. الثمن المعروض: ${price} درهم.`;
    return `<article class="product-card" data-type="${p.product_type}">
      <div class="product-image">${image}</div>
      <div class="product-info"><span class="product-type">${typeLabel}</span><h3>${escapeHtml(p.name)}</h3>
      <p>${escapeHtml(p.description || "")}</p><div class="product-bottom"><span class="price">${price} درهم</span>
      <a class="button" href="${waLink(msg)}" target="_blank" rel="noopener">اطلب عبر واتساب</a></div></div></article>`;
  }
  function escapeHtml(s) {
    return String(s ?? "").replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }
  function render() {
    const shown = products.filter(p => currentFilter === "all" || p.product_type === currentFilter);
    grid.innerHTML = shown.map(card).join("");
    empty.classList.toggle("hidden", shown.length > 0);
    grid.classList.toggle("hidden", shown.length === 0);
  }
  document.querySelectorAll(".filter").forEach(b => b.addEventListener("click", () => {
    currentFilter = b.dataset.filter;
    document.querySelectorAll(".filter").forEach(x => x.classList.toggle("active", x === b));
    render();
  }));

  async function loadProducts() {
    if (!sb) {
      grid.innerHTML = '<div class="notice">المتجر جاهز للتجربة، لكن خاص ربط قاعدة بيانات Supabase أولاً. اتبع دليل الإعداد داخل ملفات المشروع.</div>';
      empty.classList.add("hidden");
      return;
    }
    const { data, error } = await sb.from("products").select("id,name,description,price,product_type,image_url,is_published,created_at").eq("is_published", true).order("created_at", { ascending: false });
    if (error) {
      grid.innerHTML = '<div class="notice error">تعذر تحميل المنتجات حالياً. تأكد من إعداد قاعدة البيانات وسياسات الوصول.</div>';
      return;
    }
    products = data || [];
    render();
  }
  loadProducts();
})();
