// ضع معلومات مشروع Supabase هنا بعد إنشائه.
// هذه القيم العامة (Project URL و anon/publishable key) مخصصة للواجهة.
// لا تضع أبداً service_role key أو كلمة مرور داخل هذا الملف.
window.FAN_CONFIG = {
  SUPABASE_URL: "PASTE_SUPABASE_PROJECT_URL_HERE",
  SUPABASE_ANON_KEY: "PASTE_SUPABASE_ANON_OR_PUBLISHABLE_KEY_HERE",
  WHATSAPP_NUMBER: "2126XXXXXXXX" // رقمك بصيغة دولية، بدون + أو مسافات
};
