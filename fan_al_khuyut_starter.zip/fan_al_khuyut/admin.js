(() => {
  const cfg = window.FAN_CONFIG || {};
  const configured = cfg.SUPABASE_URL && cfg.SUPABASE_ANON_KEY &&
    !cfg.SUPABASE_URL.includes("PASTE_") && !cfg.SUPABASE_ANON_KEY.includes("PASTE_");
  const sb = configured && window.supabase ? window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY) : null;
  const $ = id => document.getElementById(id);
  const loginPanel = $("loginPanel"), dashboard = $("dashboard");
  function notice(id, message, type="") {
    const el = $(id); el.textContent = message; el.className = "notice " + type;
    el.classList.remove("hidden");
  }
  function clearNotice(id) { $(id).classList.add("hidden"); }
  function escapeHtml(s) { return String(s ?? "").replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
  function showSession(session) {
    loginPanel.classList.toggle("hidden", !!session);
    dashboard.classList.toggle("hidden", !session);
    if (session) loadProducts();
  }
  if (!sb) {
    notice("loginNotice", "قبل الدخول، افتح config.js وأضف رابط مشروع Supabase والمفتاح العام (anon/publishable key).", "error");
  } else {
    sb.auth.getSession().then(({data}) => showSession(data.session));
    sb.auth.onAuthStateChange((_event, session) => showSession(session));
  }
  $("loginForm").addEventListener("submit", async e => {
    e.preventDefault(); clearNotice("loginNotice");
    if (!sb) return notice("loginNotice", "أكمل إعداد config.js أولاً.", "error");
    const {error} = await sb.auth.signInWithPassword({email:$("email").value.trim(), password:$("password").value});
    if (error) notice("loginNotice", "تعذر تسجيل الدخول. تحقق من البريد وكلمة المرور وإعداد Supabase.", "error");
  });
  $("logoutBtn").addEventListener("click", async () => { if (sb) await sb.auth.signOut(); });
  $("resetBtn").addEventListener("click", resetForm);
  function resetForm() {
    $("productForm").reset(); $("productId").value = ""; $("published").checked = true;
    $("formTitle").textContent = "إضافة منتج جديد"; $("saveBtn").textContent = "حفظ المنتج"; clearNotice("adminNotice");
  }
  async function loadProducts() {
    if (!sb) return;
    const el = $("adminProducts"); el.textContent = "جارٍ التحميل…";
    const {data,error} = await sb.from("products").select("*").order("created_at", {ascending:false});
    if (error) { el.textContent = "تعذر تحميل المنتجات. راجع سياسات قاعدة البيانات في دليل الإعداد."; return; }
    if (!data.length) { el.textContent = "لا توجد منتجات بعد. أضف أول منتج من النموذج أعلاه."; return; }
    el.innerHTML = data.map(p => `<div class="admin-item">
      ${p.image_url ? `<img src="${escapeHtml(p.image_url)}" alt="">` : `<div class="product-placeholder">🧶</div>`}
      <div class="item-copy"><b>${escapeHtml(p.name)}</b><small>${Number(p.price).toLocaleString("ar-MA")} درهم · ${p.product_type === "digital" ? "رقمي" : "حسب الطلب"} · ${p.is_published ? "منشور" : "مسودة"}</small></div>
      <button class="button button-outline" data-edit="${p.id}">تعديل</button><button class="button danger" data-delete="${p.id}">حذف</button>
    </div>`).join("");
    el.querySelectorAll("[data-edit]").forEach(b => b.addEventListener("click", () => editProduct(data.find(p => p.id === b.dataset.edit))));
    el.querySelectorAll("[data-delete]").forEach(b => b.addEventListener("click", () => deleteProduct(b.dataset.delete)));
  }
  function editProduct(p) {
    $("productId").value = p.id; $("name").value = p.name; $("price").value = p.price;
    $("productType").value = p.product_type; $("description").value = p.description || "";
    $("published").checked = !!p.is_published; $("formTitle").textContent = "تعديل المنتج";
    $("saveBtn").textContent = "حفظ التعديلات"; window.scrollTo({top:0,behavior:"smooth"});
  }
  async function deleteProduct(id) {
    if (!confirm("هل تريد حذف هذا المنتج نهائياً؟")) return;
    const {error} = await sb.from("products").delete().eq("id", id);
    if (error) notice("adminNotice", "لم يتم الحذف. تحقق من الصلاحيات.", "error");
    else { notice("adminNotice", "تم حذف المنتج.", "success"); loadProducts(); }
  }
  $("productForm").addEventListener("submit", async e => {
    e.preventDefault(); clearNotice("adminNotice");
    if (!sb) return notice("adminNotice", "قاعدة البيانات غير مربوطة.", "error");
    const session = (await sb.auth.getSession()).data.session;
    if (!session) return notice("adminNotice", "انتهت الجلسة. سجل الدخول من جديد.", "error");
    const id = $("productId").value;
    const payload = {name:$("name").value.trim(), price:Number($("price").value), product_type:$("productType").value,
      description:$("description").value.trim(), is_published:$("published").checked, updated_at:new Date().toISOString()};
    const file = $("imageFile").files[0];
    if (file) {
      if (!file.type.startsWith("image/")) return notice("adminNotice", "المرجو اختيار ملف صورة.", "error");
      if (file.size > 2 * 1024 * 1024) return notice("adminNotice", "الصورة أكبر من 2 ميغابايت. صغّرها ثم أعد المحاولة.", "error");
      const ext = (file.name.split(".").pop() || "jpg").toLowerCase().replace(/[^a-z0-9]/g,"") || "jpg";
      const path = `${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
      const {error:uploadError} = await sb.storage.from("product-images").upload(path, file, {cacheControl:"3600",upsert:false,contentType:file.type});
      if (uploadError) return notice("adminNotice", "فشل رفع الصورة. تأكد من إنشاء bucket باسم product-images وتطبيق سياساته.", "error");
      payload.image_url = sb.storage.from("product-images").getPublicUrl(path).data.publicUrl;
    }
    const result = id ? await sb.from("products").update(payload).eq("id",id) : await sb.from("products").insert(payload);
    if (result.error) return notice("adminNotice", "لم يتم حفظ المنتج. تحقق من SQL وسياسات الوصول.", "error");
    notice("adminNotice", id ? "تم تحديث المنتج بنجاح." : "تمت إضافة المنتج بنجاح.", "success");
    resetForm(); loadProducts();
  });
})();
